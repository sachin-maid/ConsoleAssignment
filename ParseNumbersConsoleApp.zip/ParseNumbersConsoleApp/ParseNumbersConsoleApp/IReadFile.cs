﻿// See https://aka.ms/new-console-template for more information
namespace ConsoleParse
{
    public interface IReadFile
    {
        void ReadFileContent();
    }
}