﻿// See https://aka.ms/new-console-template for more information
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;

namespace ConsoleParse
{
    partial class Program
    {

        //Initiating config file, Serilog console and file log writter
        static void Main(string[] args)
        {
            var builder = new ConfigurationBuilder();
            BuildConfig(builder);
           
            Log.Logger = new LoggerConfiguration()
            .ReadFrom.Configuration(builder.Build())
            .Enrich.FromLogContext()
            .WriteTo.Console()
            .WriteTo.File(@"C:\\ParseNumbersConsoleApp\\Output.txt", rollingInterval: RollingInterval.Day) //Output log file path
            .CreateLogger();

            Log.Logger.Information("App start");

            var host = Host.CreateDefaultBuilder()
                 .ConfigureServices((context, services) => {
                     services.AddTransient<IReadFile, ReadFile>();
                 }).UseSerilog()
                 .Build();
            var svc = ActivatorUtilities.CreateInstance<ReadFile>(host.Services);
            svc.ReadFileContent();

            //Initializing Configuration enviromnet config file
            static void BuildConfig(IConfigurationBuilder builder)
            {
                builder.SetBasePath(Directory.GetCurrentDirectory())
                    .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                    .AddJsonFile($"appsettings.{Environment.GetEnvironmentVariable("ASPNETCORE_ENVIROMENT") ?? "Production"}.json", optional: true)
                    //In case we have different environment. If only one envirnoment available it will igonre envirnoment settings
                    .AddEnvironmentVariables();
            }

        }
    }
 }