﻿// See https://aka.ms/new-console-template for more information
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace ConsoleParse
{
    partial class Program
    {
        public class ReadFile : IReadFile
        {
            private readonly ILogger<ReadFile> _log;
            private readonly IConfiguration _config;

            public ReadFile(ILogger<ReadFile> log, IConfiguration config)
            {
                _log = log;
                _config = config;
            }

            // function used to read file using StreamReader.
            // File path reffered from config file
            public void ReadFileContent()
            {
                _log.LogInformation("Run");
                try
                {
                   
                    string filePath = _config.GetValue<string>("filePath");
                    if (String.IsNullOrEmpty(filePath))
                    {
                        _log.LogWarning("Read file path is null.");
                        
                        return;
                    }

                    _log.LogInformation(filePath);

                    using (var sr = new StreamReader(filePath))
                    {
                        string line;
                        // Read and display lines from the file until the end of
                        // the file is reached.
                        while ((line = sr.ReadLine()) != null)
                        {
                            _log.LogInformation(line);
                            string[] subs = line.Split(',');
                            int totalValue = 0;
                            int totalEvenValue = 0;
                            foreach (var sub in subs)
                            {
                                bool isNumeric = int.TryParse(sub, out int n);
                                if (isNumeric)
                                {
                                    totalValue = SumOfNumbers(totalValue, n);
                                    totalEvenValue = SumOfEvenNumbers(totalEvenValue, n);
                                }
                                else {
                                    _log.LogError("'{sub}' is not number and was ignored.",sub);
                                }
                            }
                            _log.LogInformation("Sum of numbers : {totalValue}", totalValue);
                            _log.LogInformation("Sum of even numbers : {totalValue}", totalEvenValue);

                        }
                    }


                }
                catch (Exception e)
                {

                    _log.LogError("Error while file read {Error}", e.Message);
                }
            }

            // Returns sum of all two numbers
            public int SumOfNumbers(int total, int n) {
                return total += n;
            }

            //Retuns added value of even number
            public int SumOfEvenNumbers(int totalEven, int n)
            {
                if (n % 2 == 0)
                {
                    totalEven += n;
                }
                return totalEven;


            }
        }
    }
 }